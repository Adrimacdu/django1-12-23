
class coreMixin():
        def get_context_data(self, **kwargs):
                context = super().get_context_data(**kwargs)
                context['titulo_actualizacion'] = self.titulo_actualizacion
                context['titulo_creacion'] = self.titulo_creacion
                context['url_borrado'] = self.url_borrado
                return context
                