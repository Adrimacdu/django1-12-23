from django.shortcuts import render

# Create your views here.

from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from core.models import Modulo, ResAprendizaje, CritEvaluacion
from django.urls import reverse_lazy
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse
from core.mixins import coreMixin


class ModuloListView(ListView):
    model = Modulo
    template_name = 'core/modulo_list.html'
    # UD6.8.a
    paginate_by = 2


class ModuloDetailView(DetailView):
    model = Modulo
    template_name = 'core/modulo_detail.html'


class RAListView(ListView):
    model = ResAprendizaje
    template_name = 'core/ra_list.html'
     # UD6.8.a
    paginate_by = 2


class RADetailView(DetailView):
    model = ResAprendizaje
    template_name = 'core/ra_detail.html'


class CEListView(ListView):
    model = CritEvaluacion
    template_name = 'core/ce_list.html'
     # UD6.8.a
    paginate_by = 2


class CEDetailView(DetailView):
    model = CritEvaluacion
    template_name = 'core/ce_detail.html'

    
#UD7.2.a
class ModCreateView(coreMixin, CreateView):
    model= Modulo
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('modulo_update')
    titulo_actualizacion = 'módulo'
    titulo_creacion = 'creando un modulo'
    url_borrado = 'modulo_delete'

    fields = ['codigo', 'nombre']

#UD7.2.a
class ModUpdateView(coreMixin, UpdateView):
    model= Modulo
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('modulo_update')
    titulo_actualizacion = 'módulo'
    titulo_creacion = 'actualizando un modulo'
    url_borrado = 'modulo_delete'

    fields = ['codigo', 'nombre']

#UD7.2.a
class ModDeleteView(DeleteView):
    model= Modulo
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('modulo_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
        
#UD7.2.a
class RACreateView(coreMixin, CreateView):
    model= ResAprendizaje
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ra_update')
    titulo_actualizacion = 'resultado aprendizaje'
    titulo_creacion = 'creando un resultado de aprendizaje'
    url_borrado = 'ra_delete'
    
    fields = ['modulo', 'codigo', 'descripcion']

#UD7.2.a
class RAUpdateView(coreMixin, UpdateView):
    model= ResAprendizaje
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ra_update')
    titulo_actualizacion = 'resultado aprendizaje'
    titulo_creacion = 'actualizando un resultado aprendizaje'
    url_borrado = 'ra_delete'

    fields = ['modulo', 'codigo', 'descripcion']

#UD7.2.a
class RADeleteView(DeleteView):
    model= ResAprendizaje
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('ra_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
        
#UD7.2.a
class CECreateView(coreMixin, CreateView):
    model= CritEvaluacion
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ce_update')
    titulo_actualizacion = 'criterio evaluación'
    titulo_creacion = 'creando un criterio de evaluación'
    url_borrado = 'ce_delete'

    fields = ['resultado_aprendizaje', 'codigo', 'descripcion', 'minimo']

#UD7.2.a
class CEUpdateView(coreMixin, UpdateView):
    model = CritEvaluacion
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ce_update')
    titulo_actualizacion = 'criterio evaluación'
    titulo_creacion = 'actualizando un criterio de evaluación'
    url_borrado = 'ce_delete'

    fields = ['resultado_aprendizaje', 'codigo', 'descripcion', 'minimo']

#UD7.2.a
class CEDeleteView(DeleteView):
    model = CritEvaluacion
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('ce_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))