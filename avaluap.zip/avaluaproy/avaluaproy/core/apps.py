from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    # UD6.4.d
    name = 'core'
    verbose_name = 'core'
