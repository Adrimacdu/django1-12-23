from django.shortcuts import render

# Create your views here.

from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from programacion_didactica.models import Unidad, InstEvaluacion, PondRA, PondCriterio, PondCritUD
from django.urls import reverse_lazy
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.http import request
from core.mixins import coreMixin

# UD6.7.a

class UnidadListView(ListView):
    model = Unidad
    template_name = 'programacion_didactica/unidad_list.html'

class UnidadDetailView(DetailView):
    model = Unidad
    template_name = 'programacion_didactica/unidad_detail.html'

class InstEvListView(ListView):
    model = InstEvaluacion
    template_name = 'programacion_didactica/ie_list.html'

class InstEvDetailView(DetailView):
    model = InstEvaluacion
    template_name = 'programacion_didactica/ie_detail.html'

class PondRAListView(ListView):
    model = PondRA
    template_name = 'programacion_didactica/pond_ra_list.html'

class PondRADetailView(DetailView):
    model = PondRA
    template_name = 'programacion_didactica/pond_ra_detail.html'

class PondCritListView(ListView):
    model = PondCriterio
    template_name = 'programacion_didactica/pond_ce_list.html' 

class PondCritDetailView(DetailView):
    model = PondCriterio
    template_name = 'programacion_didactica/pond_ce_detail.html'

class PondCritUDListView(ListView):
    model = PondCritUD
    template_name = 'programacion_didactica/pond_ce_ud_list.html'

class PondCritUDDetailView(DetailView):
    model = PondCritUD
    template_name = 'programacion_didactica/pond_ce_ud_detail.html'


#UD7.2.a

class UDCreateView(coreMixin, CreateView):
    model= Unidad
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('ud_create')
    titulo_actualizacion = 'unidad'
    titulo_creacion = 'crear un criterio de evaluación'
    url_borrado = 'unidad_delete'

#UD7.2.a
class UDUpdateView(coreMixin, UpdateView):
    model = Unidad
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('ud_update')
    titulo_actualizacion = 'unidad'
    titulo_creacion = 'actualizar un criterio de evaluación'
    url_borrado = 'unidad_delete'

#UD7.2.a
class UDDeleteView(DeleteView):
    model = Unidad
    template_name = 'core/base_confirm_delete.html'
    success_url = reverse_lazy('ud_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))

#UD7.2.a
class InstEvaluacionCreateView(coreMixin, CreateView):
    model= InstEvaluacion
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('ie_create')
    titulo_actualizacion = 'instrumento evaluacion'
    titulo_creacion = 'crear un instrumento de evaluacion'
    url_borrado = 'ie_delete'

#UD7.2.a
class InstEvaluacionUpdateView(coreMixin, UpdateView):
    model = InstEvaluacion
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('ie_update')
    titulo_actualizacion = 'instrumento evaluacion'
    titulo_creacion = 'actualizar un instrumento de evaluacion'
    url_borrado = 'ie_delete'

#UD7.2.a
class InstEvaluacionDeleteView(DeleteView):
    model = InstEvaluacion
    template_name = 'core/base_confirm_delete.html'
    success_url = reverse_lazy('ie_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
    
#UD7.2.a
class PonderacionRACreateView(coreMixin, CreateView):
    model= PondRA
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('pond_ra_create')
    titulo_actualizacion = 'instrumento evaluacion'
    titulo_creacion = 'crear un resultado de aprendizaje'
    url_borrado = 'pond_ra_delete'

#UD7.2.a
class PonderacionRAUpdateView(coreMixin, UpdateView):
    model = PondRA
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('pond_ra_update')
    titulo_actualizacion = 'instrumento evaluacion'
    titulo_creacion = 'actualizar un resultado aprendizaje'
    url_borrado = 'pond_ra_delete'

#UD7.2.a
class PonderacionRADeleteView(DeleteView):
    model = PondRA
    template_name = 'core/base_confirm_delete.html'
    success_url = reverse_lazy('pond_ra_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
    
#UD7.2.a
class PondCriterioCreateView(coreMixin, CreateView):
    model= PondCriterio
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('pond_ce_create')
    titulo_actualizacion = 'ponderacion criterio de evaluacion'
    titulo_creacion = 'crear una ponderacion criterio de evaluacion'
    url_borrado = 'pond_ce_delete'

#UD7.2.a
class PondCriterioUpdateView(coreMixin, UpdateView):
    model = PondCriterio
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('pond_ce_update')
    titulo_actualizacion = 'ponderacion criterio de evaluacion'
    titulo_creacion = 'actualizar una ponderacion criterio de evaluacion'
    url_borrado = 'pond_ce_delete'

#UD7.2.a
class PondCriterioDeleteView(DeleteView):
    model = PondCriterio
    template_name = 'core/base_confirm_delete.html'
    success_url = reverse_lazy('pond_ce_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
        
#UD7.2.a
class PondCriterioUDCreateView(coreMixin, CreateView):
    model= PondCritUD
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('pond_ce_ud_create')
    titulo_actualizacion = 'ponderacion criterio de evaluacion por unidad'
    titulo_creacion = 'crear una ponderacion criterio de evaluacion por unidad'
    url_borrado = 'pond_ce_ud_delete'

#UD7.2.a
class PondCriterioUDUpdateView(coreMixin, UpdateView):
    model = PondCritUD
    template_name = 'core/base_create_update.html'
    success_url = reverse_lazy('pond_ce_ud_update')
    titulo_actualizacion = 'ponderacion criterio de evaluacion por unidad'
    titulo_creacion = 'actualizar un ponderacion criterio de evaluacion por unidad'
    url_borrado = 'pond_ce_ud_delete'

#UD7.2.a
class PondCriterioUDDeleteView(DeleteView):
    model = PondCritUD
    template_name = 'core/base_confirm_delete.html'
    success_url = reverse_lazy('pond_ce_ud_list')

    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
        
#UD7.2.a